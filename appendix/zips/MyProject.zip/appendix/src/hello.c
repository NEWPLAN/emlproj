#include <stdio.h>
#include <gmime/gmime.h>


void GetHeader(GMimeMessage* pMessage);


void MyInitAll(char * filename,FILE** p);

void MyInitAll(char * filename, FILE** p)
{
	return ;
}



static void
count_foreach_callback (GMimeObject *parent, GMimeObject *part, gpointer user_data)
{
	int *count = user_data;

	(*count)++;

	/* 'part' points to the current part node that
	 * g_mime_message_foreach() is iterating over */

	/* find out what class 'part' is... */
	if (GMIME_IS_MESSAGE_PART (part))
	{
		/* message/rfc822 or message/news */
		GMimeMessage *message;

		/* g_mime_message_foreach() won't descend into
                   child message parts, so if we want to count any
                   subparts of this child message, we'll have to call
                   g_mime_message_foreach() again here. */

		message = g_mime_message_part_get_message ((GMimeMessagePart *) part);
		g_mime_message_foreach (message, count_foreach_callback, count);
	}
	else if (GMIME_IS_MESSAGE_PARTIAL (part))
	{
		/* message/partial */
		/* this is an incomplete message part, probably a
                   large message that the sender has broken into
                   smaller parts and is sending us bit by bit. we
                   could save some info about it so that we could
                   piece this back together again once we get all the
                   parts? */

	} else if (GMIME_IS_MULTIPART (part))
	{
		/* multipart/mixed, multipart/alternative,
		 * multipart/related, multipart/signed,
		 * multipart/encrypted, etc... */

		/* we'll get to finding out if this is a
		 * signed/encrypted multipart later... */
	} else if (GMIME_IS_PART (part))
	{
		/* a normal leaf part, could be text/plain or
		 * image/jpeg etc */
	} else
	{
		g_assert_not_reached ();
	}
}

static void
count_parts_in_message (GMimeMessage *message)
{
	int count = 0;

	/* count the number of parts (recursively) in the message
	 * including the container multiparts */
	g_mime_message_foreach (message, count_foreach_callback, &count);

	printf ("There are %d parts in the message\n", count);
}





void Walk(const GMimeObject* pPart,int nDepth)
{

    printf("Geting %d part content type...\n",nDepth);

    const GMimeContentType* pContentType = g_mime_object_get_content_type(pPart) ;

    char* szContentType = g_mime_content_type_to_string(pContentType);

    printf("The content type is: %s or direct get from the object(%s/%s)\n",
						szContentType,pContentType->type,pContentType->subtype);

    g_free(szContentType);


    char* szObject = g_mime_object_to_string(pPart);

    //printf("The object is :%s\n",szObject);

    g_free(szObject);

    const char* szHeader = g_mime_object_get_headers(pPart);

    printf("The object's header is:%s\n",szHeader);

    const char* szContentId = g_mime_object_get_content_id (pPart);
    printf("The object's content id is:%s\n",szContentId);

    if(GMIME_IS_MULTIPART(pPart))
    {
        GMimeMultipart* pMultipart = GMIME_MULTIPART(pPart);
        printf("[log]:\tThe GMimeObject can convert to GMimeMultiPart object...\n");
        printf("The multipart preface is: %s\n",g_mime_multipart_get_preface (GMIME_MULTIPART(pPart)));
        printf("The multipart number is %d\n",g_mime_multipart_get_count (pMultipart));
        printf("The multipart boundary is:%s\n",g_mime_multipart_get_boundary(pMultipart));

        /*
        *对一个混合型邮件体，获取其混合对象链表。利用该链表对象可遍历混合体中的各部分
        */
        GList* pSubParts =  NULL;//pMultipart->subparts;
				GMimeObject * nextpart=g_mime_multipart_get_part(pMultipart,1);
				printf("next part is :%s\n",g_mime_object_to_string(nextpart));

				{
					printf("Geting %d part content type...\n",1);

			    const GMimeContentType* pContentType = g_mime_object_get_content_type(nextpart) ;

			    char* szContentType = g_mime_content_type_to_string(pContentType);

			    printf("The content type is: %s or direct get from the object(%s/%s)\n",
									szContentType,pContentType->type,pContentType->subtype);

			    g_free(szContentType);
				}


        if(pSubParts==NULL)
            printf("[log]:\tThe multipart has no subparts, wrong mail????\n");
        int j=0;

		/*
		*遍历组成混合体的各部分邮件体对象
		*/
        while(pSubParts)
        {
            pSubParts = pSubParts->next;
            printf("multi part no%d\n",j++);
        }
    }
}

void Analyze(GMimeMessage* pMessage)
{
    printf("[log]:\tanalyze the message begin...\n");
    Walk(pMessage->mime_part,0);
}

int main(int argc,char** argv)
{
	/*init for each program*/
    g_mime_init(0);
    if(argc<2)
    {
        printf("[log]:\terror open file to parser. hello <file>\n");
        return 0;
    }

    printf("[log]:\thello, gmime! please\n");
    FILE* fp = fopen(argv[1],"rb");
    /*create a new stream...*/
    GMimeStream* pStream = g_mime_stream_file_new(fp);
    printf("[log]:\t[main] g_mime_stream_file_new success!\n");

    /*set the filter
    *创建一个CRLF过滤器，过滤器介绍见前述。一般而言，MTA之间的通信每行都是以\n结尾的，但因为我们要处理以CRLF结尾的邮件体，所以必须附加一个CRLF过滤器来处理\r\n.
    */
    GMimeFilter* pCrlfFilter = g_mime_filter_crlf_new (FALSE,TRUE);

    printf("[log]:\t[main] new crlf filter success!\n");

	/*根据初始文件流和过滤器创建一个具备过滤功能的流对象*/
    GMimeStream* pFilterStream = g_mime_stream_filter_new (pStream);

    printf("[log]:\t[main] create filter stream with file stream success!\n");
    printf("[log]:\tunref the stream object.\n");

    //g_mime_stream_unref(pStream);
		g_object_unref (pStream);
    g_mime_stream_filter_add (GMIME_STREAM_FILTER (pFilterStream), pCrlfFilter);

    g_object_unref (pCrlfFilter);
    printf("[log]:\t[main] add crlf filter to decode success!\n");

    /*
    *创建一个MIME解析器，分析器可对一封邮件进行解析，生成消息对象。在消息对象对邮件消息进行结构化的存储。通过消息对象可以遍历邮件各部分内容
    */
    GMimeParser* pParser = g_mime_parser_new();

    if(!pParser)
    {
        printf("[log]:\terror new parser.\n");
    }
    printf("[log]:\tnew parser success!\n");

	/*
	*根据输入流对象对MIME解析器进行初始化
	*/
    g_mime_parser_init_with_stream(pParser,pFilterStream);
	/*
	*利用MIME解析器生成消息对象
	*/
    GMimeMessage* pMessage = g_mime_parser_construct_message(pParser);

    if(!pMessage)
    {
        printf("[log]:\terror construct the message!\n");
        return 0;
    }
    printf("[log]:\tconstruct message with filter stream success!\n");
    printf("[log]:\tunref the filter stream.\n");
    //g_mime_stream_unref(pFilterStream);
		g_object_unref (pFilterStream);
    printf("[log]:\tunref the parser object.\n");
    g_object_unref(pParser);

    /*
    *获取消息对象中的“发信人”、“收信人”和“主题”
    */
    printf("sender:%s\n",g_mime_message_get_sender(pMessage));
    printf("rcpt to:%s\n",g_mime_message_get_reply_to (pMessage));
    printf("subject:%s\n",g_mime_message_get_subject (pMessage));
    /*
    *从消息对象中获取邮件体,return to a object funtion,and decode it to char
    */
    GMimeObject * ps=g_mime_message_get_body (pMessage);
    //printf("\n\n\nbody:%s\n",  g_mime_object_to_string(ps));

    printf("message ID:%s\n",g_mime_message_get_message_id(pMessage));
    printf("date:%s\n",g_mime_message_get_date_as_string(pMessage) );
		GetHeader(pMessage);
		count_parts_in_message(pMessage);
    Analyze(pMessage);
    printf("[log]:\tunref the pMessage object.\n");
    g_object_unref(GMIME_OBJECT(pMessage));

    printf("[log]:\tshutdown for gmime\n");
    g_mime_shutdown();

    return 1;

}


void GetHeader(GMimeMessage* pMessage)
{
		GMimeHeaderList *list=NULL;
		GMimeHeaderIter iter;
		const char * name,*value;

		if(NULL==(list=g_mime_object_get_header_list(GMIME_OBJECT(pMessage))))
			printf("[log]:\tfailed to get header list\n");
		if(!g_mime_header_list_get_iter(list,&iter))
			printf("[log]:\tfailed to get header list iter!\n");
		printf("\n[log]\t Output Headers =====>>>>>\n\n");

		for(;;)
		{
			name=g_mime_header_iter_get_name(&iter);
			value=g_mime_header_iter_get_value(&iter);
			printf("%s:\t %s\n", name, value);
			if (!g_mime_header_iter_next(&iter))
			{
					break;/* code */
			}
		}
}
