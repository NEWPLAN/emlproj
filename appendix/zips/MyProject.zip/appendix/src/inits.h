#ifndef  __INITS_H__TEST__
#define  __INITS_H__TEST__
#include <gmime/gmime.h>
#include <stdio.h>
GMimeMessage* AllInits(int argc, char **argv);
void AllFree(GMimeMessage *);
#endif
