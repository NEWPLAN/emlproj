#include "analyze.h"

static void
write_message_to_screen (GMimeMessage *message);

void Walk(const GMimeObject* pPart,int nDepth)
{

    printf("Geting %d part content type...\n",nDepth);

    const GMimeContentType* pContentType = g_mime_object_get_content_type(pPart) ;

    char* szContentType = g_mime_content_type_to_string(pContentType);

    printf("The content type is: %s or direct get from the object(%s/%s)\n",
						szContentType,pContentType->type,pContentType->subtype);

    g_free(szContentType);


    char* szObject = g_mime_object_to_string(pPart);

    //printf("The object is :%s\n",szObject);

    g_free(szObject);

    const char* szHeader = g_mime_object_get_headers(pPart);

    printf("The object's header is:%s\n",szHeader);

    const char* szContentId = g_mime_object_get_content_id (pPart);
    printf("The object's content id is:%s\n",szContentId);

    if(GMIME_IS_MULTIPART(pPart))
    {
        GMimeMultipart* pMultipart = GMIME_MULTIPART(pPart);
        printf("[log]:\tThe GMimeObject can convert to GMimeMultiPart object...\n");
        printf("The multipart preface is: %s\n",g_mime_multipart_get_preface (GMIME_MULTIPART(pPart)));
        printf("The multipart number is %d\n",g_mime_multipart_get_count (pMultipart));
        printf("The multipart boundary is:%s\n",g_mime_multipart_get_boundary(pMultipart));

        /*
        *对一个混合型邮件体，获取其混合对象链表。利用该链表对象可遍历混合体中的各部分
        */
        GList* pSubParts =  NULL;//pMultipart->subparts;
		GMimeObject * nextpart=g_mime_multipart_get_part(pMultipart,1);
		//printf("next part is :\n%s\n", (g_mime_object_to_string(nextpart));
#if 0
        {
            printf("decode here================>>>>>>>>>>>>>>>>>>>\n" );
            GMimeStream *stream = g_mime_stream_file_new (stdout);
            GMimeDataWrapper * content=g_mime_part_get_content_object(nextpart);
            //GMimeStream *decoded=g_mime_stream_mem_new();
            g_mime_data_wrapper_write_to_stream(content,stream);
            //g_mime_stream_write_string(decoded,"hello this is newplan\n");
            //char pps[1000]={0};
            //g_mime_stream_read (decoded,pps,1000);
            //printf("%s\n",pps);
        }
        {
            printf("Geting %d part content type...\n",1);
            const GMimeContentType* pContentType = g_mime_object_get_content_type(nextpart) ;
            char* szContentType = g_mime_content_type_to_string(pContentType);
            printf("The content type is: %s or direct get from the object(%s/%s)\n",
									szContentType,pContentType->type,pContentType->subtype);
            g_free(szContentType);
        }


        if(pSubParts==NULL)
            printf("[log]:\tThe multipart has no subparts, wrong mail????\n");
        int j=0;

		/*
		*遍历组成混合体的各部分邮件体对象
		*/
        while(pSubParts)
        {
            pSubParts = pSubParts->next;
            printf("multi part no%d\n",j++);
        }
#endif
    }
}

void Analyze(GMimeMessage* pMessage)
{
    printf("[log]:\tanalyze the message begin...\n");
    Walk(pMessage->mime_part,0);
    //write_message_to_screen(pMessage);
}

static void
write_message_to_screen (GMimeMessage *message)
{
	GMimeStream *stream;

	/* create a new stream for writing to stdout */
	stream = g_mime_stream_file_new (stdout);
	g_mime_stream_file_set_owner ((GMimeStreamFile *) stream, FALSE);

	/* write the message to the stream */
	g_mime_object_write_to_stream ((GMimeObject *) message, stream);

	/* flush the stream (kinda like fflush() in libc's stdio) */
	g_mime_stream_flush (stream);

	/* free the output stream */
	g_object_unref (stream);
}
