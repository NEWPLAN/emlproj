#ifndef __BASICINFO_H__TEST__
#define  __BASICINFO_H__TEST__
#include <gmime/gmime.h>
void GetBasicInfo(GMimeMessage * pMessage);
#endif
