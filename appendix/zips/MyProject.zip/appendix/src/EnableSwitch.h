#ifndef __ENABLESWITCH_H__TEST__
#define  __ENABLESWITCH_H__TEST__
/*初始化LOG开关*/
#define  ENABLE_INITS_LOG   0
#define  ENABLE_MESSAGE_LOG 0
#define  ENABLE_HEADERS_LOG 0
#endif
