#ifndef __HEADS_H__TEST__
#define  __HEADS_H__TEST__
#include <gmime/gmime.h>
void GetHeader(GMimeMessage* pMessage);
#endif
