#ifndef __ANALYZE_H__TEST__
#define  __ANALYZE_H__TEST__
#include <gmime/gmime.h>
void Analyze(GMimeMessage* pMessage);
#endif
