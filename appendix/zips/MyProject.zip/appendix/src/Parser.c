#include <gmime/gmime.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char * GetBody(GMimePart * mime_part)
{


	char* data;
	int iRe=0,ichar=0,iencode =0;

	if( NULL==mime_part )
	{
        printf("error");
		return NULL ;
	}

	GMimeContentEncoding ReEncoding = g_mime_part_get_content_encoding(mime_part);

	char* szCharset = (char*)g_mime_object_get_content_type_parameter((GMimeObject*)mime_part,"charset");
    printf("char set is %s\n",szCharset );
	GMimeDataWrapper *dataWrap = g_mime_part_get_content_object(mime_part);

	GMimeStream * gmime_stream= g_mime_data_wrapper_get_stream(dataWrap);
	//encoding转码
	GMimeFilter * pAttFilter =  g_mime_filter_basic_new(ReEncoding,FALSE);
	GMimeStream* pFilterStream =  g_mime_stream_filter_new(gmime_stream);

	iencode = g_mime_stream_filter_add (GMIME_STREAM_FILTER (pFilterStream), pAttFilter);
	//charset转码
	gint64 size = g_mime_stream_length(pFilterStream);

	g_object_unref ( pAttFilter );


	if (pFilterStream && size >0)
	{

		char* szTemp=NULL;
		szTemp = (char*)malloc( size * 3 );
		char* current =szTemp;
		memset(szTemp,0,size*3);
		while ( (current-szTemp) < size)
		{
			iRe = g_mime_stream_read(pFilterStream,current,size );
			int iLength= strlen(szTemp);

			if(iRe>0)
				current += iRe;
			else
				break;

		}
		size = current-szTemp;
		if (size >0)
		{
			if(szCharset != NULL)
			{

				char * pUtf8Buff = NULL;
                 pUtf8Buff=g_mime_iconv_locale_to_utf8(szTemp);
                printf("%s\n",pUtf8Buff );
				if( pUtf8Buff !=NULL )
				{
					free( pUtf8Buff  );
				}
				if(szTemp != NULL)
				{
					free(szTemp);
					szTemp = NULL;
				}

			}
			else
			{
                printf("%s\n",szTemp );
				if(szTemp != NULL)
				{
					free(szTemp);
					szTemp = NULL;
				}

			}


		}

		g_mime_stream_filter_remove((GMimeStreamFilter*)pFilterStream,ichar);
		g_mime_stream_filter_remove((GMimeStreamFilter*)pFilterStream,iencode);

		g_object_unref (pFilterStream);
		//g_object_unref (gmime_stream);

	}
	else
	{
		g_mime_stream_filter_remove((GMimeStreamFilter*)pFilterStream,ichar);
		g_mime_stream_filter_remove((GMimeStreamFilter*)pFilterStream,iencode);
			g_object_unref (pFilterStream);
		//g_object_unref (gmime_stream);

		return "error";
	}


	return NULL;
}
