#ifndef __ALL_H__TEST__
#define  __ALL_H__TEST__
#include "inits.h"
#include "heads.h"
#include "messageB.h"
#include "basicInfo.h"
#include "analyze.h"
#endif
