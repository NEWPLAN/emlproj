/*************************************************************************
	> File Name: all.h
	> Author: 
	> Mail: 
	> Created Time: 2016��02��24�� ������ 18ʱ03��12��
 ************************************************************************/

#ifndef _ALL_H
#define _ALL_H
#define EML__SYSTEMS__
#ifdef  EML__SYSTEMS__
    int ZipsMain(int argc, char* argv[]);
#endif
#endif
