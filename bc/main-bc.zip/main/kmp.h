/*************************************************************************
	> File Name: kmp.h
	> Author: 
	> Mail: 
	> Created Time: 2016年03月24日 星期四 13时23分18秒
 ************************************************************************/

#ifndef _KMP_H
#define _KMP_H
int check_sub(char *src, int slen, char *pattern, int plen);
#endif
