/*************************************************************************
	> File Name: switch.h
	> Author:
	> Mail:
	> Created Time: 2016��02��23�� ���ڶ� 09ʱ52��22��
 ************************************************************************/

#ifndef EML_SWITCH_H
#define EML_SWITCH_H

/*ȫ�ֿ���*/
#ifdef EML_SYSTEM__
#undef EML_SYSTEM__
#define EML_SYSTEM__
#endif
#endif
