/*************************************************************************
	> File Name: strategy.c
	> Author: 
	> Mail: 
	> Created Time: 2016年03月24日 星期四 13时08分12秒
 ************************************************************************/

#include <stdio.h>
#include "strategy.h"

int strategy_init(void)
{
    return 0;
}
